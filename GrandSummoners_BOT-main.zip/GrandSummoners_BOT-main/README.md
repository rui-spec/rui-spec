# GrandSummoners_BOT
A simple bot using Python to auto complete the story mode of the game

I recommend you to run it in the python IDLE, you can just open, click on run module and it will start after some 5 seconds, make sure you are using on pc
You can download a emulator to run the game on your pc, when you want to stop the bot, just close the IDLE.
Have fun!
